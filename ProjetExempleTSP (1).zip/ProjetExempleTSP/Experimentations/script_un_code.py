
import sys
import time
from os import listdir
from random import randint

# here I wrote a dummy solver that returns a table
# with the name of the file, a random value and the elapsed time
# your code should return such a table with 3 elements
def monCode(nomfichier):
    tempsDebut = time.time()
    solution = randint(1,10)
    tempsEcoule = round(time.time() - tempsDebut, 4)
    return [nomfichier, solution, tempsEcoule]

directoryName = sys.argv[1]  # the first argument of the script is the name of the directory with the instance files
#print("I'm running the code on files of directory " + directoryName) # uncomment to check if the code is run on the right files

outputFileName = sys.argv[2] # the second argument is the name of the output file

argumentList = listdir(directoryName) # argumentList contains the name of the test files

#print(argumentList)    # uncomment to check if the code is run on the right files

output = [] # this will contain the list of outputs

for fileName in argumentList:       # for each test file
    output.append(monCode(sys.argv[1]+"/"+fileName))    # append the result of the algorithm applied to this test file
  
outputFile = open(outputFileName,"w")
for line in output: # print all results in a .csv
    outputFile.write(line[0] + " ; " + str(line[1]) + " ; " + str(line[2]) + "\n")
outputFile.close()
