# usage : ./experimentationTSP.sh repertoire_ou_sont_les_instances repertoire_ou_on_veut_stocker_les_resultats

echo Campagne experimentale TSP
echo Repertoire de donnees $1
echo Repertoire de sortie $2

mkdir -p $2

for instance in `ls $1` ; do  # pour chaque instance dans le repertoire $1
    echo "Lancement du calcul du minorant sur " $1/$instance
    python ../Code2/main.py $1/$instance minorant | grep Minorant >> $2/minorant.csv
    done
done

