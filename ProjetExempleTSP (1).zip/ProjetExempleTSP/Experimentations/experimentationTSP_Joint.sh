# usage : ./experimentationTSP.sh repertoire_ou_sont_les_instances repertoire_ou_on_veut_stocker_les_resultats

echo Campagne experimentale TSP
echo Repertoire de donnees $1
echo Repertoire de sortie $2

mkdir -p $2
echo `date` > $2/_resume.txt

for instance in `ls $1` ; do  # pour chaque instance dans le repertoire $1
    for methode in idiot plusproche insertion; do  # pour chacune des methodes listees
        echo Lancement de la methode $methode sur $1/$instance
        python ../Code/main.py $1/$instance $methode $2/${instance}_${methode}.sol | grep Bilan >> $2/bilan_$methode.csv
    done
done

join -j 2 -t ';' -a1 -a2 -o 0,1.4,1.5,2.4,2.5 -e '-' <(sort -k2 $2/bilan_idiot.csv) <(sort -k2 $2/bilan_plusproche.csv) | join -1 1 -2 2 - <(sort -k2 $2/bilan_insertion.csv) -t ';' -a1 -a2 -o 0,1.2,1.3,1.4,1.5,2.4,2.5 -e '-' > $2/bilan.csv

sed -i '1iFichier;idiot - valeur;idot - temps CPU;plusproche - valeur;plusproche - temps CPU;insertion - valeur;insertion - temps CPU;' $2/bilan.csv

