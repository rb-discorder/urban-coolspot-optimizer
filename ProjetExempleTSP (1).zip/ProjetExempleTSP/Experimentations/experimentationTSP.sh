# usage : ./experimentationTSP.sh repertoire_ou_sont_les_instances repertoire_ou_on_veut_stocker_les_resultats

echo Campagne experimentale TSP
echo Repertoire de donnees $1
echo Repertoire de sortie $2

mkdir -p $2
echo `date` > $2/_resume.txt

for instance in `ls $1` ; do  # pour chaque instance dans le repertoire $1
    for methode in idiot plusproche insertion; do  # pour chacune des methodes listees
        echo Lancement de la methode $methode sur $1/$instance
        python ../Code/main.py $1/$instance $methode $2/${instance}_${methode}.sol
