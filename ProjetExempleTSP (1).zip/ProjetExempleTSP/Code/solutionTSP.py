#! usr/bin/python
# -*- coding: utf-8 -*-
import dataTSP

# on definit un type qui va servir a representer une solution du probleme
class TSPProblemSolution:
    "Une solution au probleme"
    

# affiche a l'ecran le cout de la solution, ainsi que la permutation
def afficheSolution(solutionTSP):
    print("La solution a pour cout " + str(solutionTSP.cout))
    print(solutionTSP.permutation)


# ecrit la valeur de la solution en premiere ligne du fichier fichierSortie
# ecrit la permutation sur la deuxieme ligne
def recordSolution(solutionTSP, fichierSortie):
    fichierSortie.write(str(solutionTSP.cout)+"\n")
    for ville in solutionTSP.permutation:
            fichierSortie.write(str(ville)+" ")
    fichierSortie.write("\n")
    

def loadSolution(fichierEntree):
    solutionTSP = TSPProblemSolution()
    solutionTSP.cout = float(fichierEntree.readline())
    solutionTSP.permutation = []
    chainePermutation = fichierEntree.readline().split(' ')
    for val in chainePermutation:
        if val.isdigit() : solutionTSP.permutation.append(int(val))
    return solutionTSP
