# -*- coding: utf-8 -*-
import math

# on definit un type qui va servir a representer une donnee de probleme
class TSPProblemData:
    "Donnees du probleme"

# cette fonction prend un fichier de donnees en parametres
# et retourne une donnee dans notre format
def lectureDonneesTSPMatrice(fichierDonnees):
    data = TSPProblemData()                   # creation de la structure pour stocker les donnees
    premiereLigne = fichierDonnees.readline() # lecture de la premiere ligne (qui contient le nombre de villes)
    data.nbVilles = int(premiereLigne)        # on recupere le nombre de villes
    data.matrix = []                          # creation de la matrice de distances
    for line in fichierDonnees :              # pour chaque ligne du fichier, on lit la ligne de la matrice correspondante
        distances = []                          # creation de la ligne courant de la matrice
        cutLine = line.split(' ')               # decoupage de la ligne en elements
        for val in cutLine :                    # pour chaque valeur
            distances.append(int(val))              # on l'ajoute dans la ligne
        data.matrix.append(distances)           # ajout de la ligne a la matrice
        
    return data                               # on retourne la donnee TSP lue dans le fichier




def lectureDonneesTSPCoordonnees(fichierDonnees):
    data = TSPProblemData()
    
    ligneCourante = fichierDonnees.readline() # lecture de la premiere ligne (qui contient le nom de l'instance)
    #print("Lecture de l'instance " + ligneCourante.split(' ')[2])
    
    fichierDonnees.readline() # lecture du commentaire
    fichierDonnees.readline() # lecture du type
    listeChaines = fichierDonnees.readline().split()
    numChaine = 0
    while numChaine < len(listeChaines) and listeChaines[numChaine].isdigit() == False:
        numChaine+=1
    data.nbVilles = int(listeChaines[numChaine])
    
    fichierDonnees.readline() # lecture du type aretes
    fichierDonnees.readline() # lecture du l'entete
    
    listCoord = []
    
    for i in range(data.nbVilles):
        listeChaines = fichierDonnees.readline().split()
        listCoord.append( (float(listeChaines[1]), float(listeChaines[2]) ) )
    
    #print(listCoord)
    
    data.matrix = []
    for i in range(data.nbVilles) :
        distancesDuSommetCourant = []
        for j in range(data.nbVilles) :
            deltaX = listCoord[i][0] - listCoord[j][0]
            deltaY = listCoord[i][1] - listCoord[j][1]
            distancesDuSommetCourant.append( round(math.sqrt(deltaX * deltaX + deltaY * deltaY)) )
        data.matrix.append(distancesDuSommetCourant)
    return data



# cette fonction affiche une instance de TSP
# (principalement utile pour les petites instances
def afficheInstanceTSP(donneeTSP):
    print("Nb villes : " + str(donneeTSP.nbVilles))
    print("Distance matrix")
    for i in range(0,donneeTSP.nbVilles):       # pour toutes les lignes
        for j in range(0,donneeTSP.nbVilles):       # pour tous les elements de la ligne
            print(donneeTSP.matrix[i][j]),              # afficher l'element
        print('\n'),                                # passer a la ligne




