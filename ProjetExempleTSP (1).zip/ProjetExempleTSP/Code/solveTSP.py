#! usr/bin/python
# -*- coding: utf-8 -*-
import dataTSP
import solutionTSP
import copy


# resolution consistant a choisir les villes dans l'ordre croissant d'indice
def resolutionTSPIdiote(donnees):
    solution = solutionTSP.TSPProblemSolution()
    solution.permutation = []
    solution.cout = 0
    for i in range(0,donnees.nbVilles):
        solution.permutation.append(i)
        solution.cout += donnees.matrix[i][(i+1)%donnees.nbVilles]
    return solution


# routine permettant de calculer le plus proche voisin non visite de la ville courante
def plusProcheVoisinNonVisite(villeCourante, donnees, villesVisitees):

    i = 0 # on se positionne sur la premiere ville
    while villesVisitees[i] == True and i < donnees.nbVilles : # on avance jusqu'au premier non visite
        i =i+1

    sommetPlusProche = i   # par defaut, le plus proche est le premier

    if(i == donnees.nbVilles) : print("Erreur : pas de plus proche voisin non visite")

    i=i+1

    while i < donnees.nbVilles :   # on avance sur les villes
        if i != villeCourante and villesVisitees[i] == False and donnees.matrix[villeCourante][i] < donnees.matrix[villeCourante][sommetPlusProche]:
            sommetPlusProche = i
        i=i+1

    return sommetPlusProche


def resolutionTSPPlusProcheVoisin(donnees, premier):
    solution = solutionTSP.TSPProblemSolution()
    solution.permutation = []
    solution.cout = 0

    # initialisation du tableau de villes visitees
    villesVisitees = [False for i in range(donnees.nbVilles)]
    villeCourante = premier

    for i in range(donnees.nbVilles):
        solution.permutation.append(villeCourante)  # on ajoute la ville courant a la solution
        villesVisitees[villeCourante] = True
        if i == donnees.nbVilles - 1 :     # si i est la derniere ville a visiter, on revient a la ville de depart
            solution.cout += donnees.matrix[villeCourante][premier]
        else:
            suivant = plusProcheVoisinNonVisite(villeCourante, donnees, villesVisitees) # on cherche la ville la plus proche de la ville courante (parmi celles non visitees)
            solution.cout += donnees.matrix[villeCourante][suivant]
        villeCourante = suivant

    return solution


# resout le probleme de TSP a l'aide de l'heuristique de la meilleure insertion
def resolutionTSPMeilleureInsertion(donnees):

    #  initialisation de la solution
    solution = solutionTSP.TSPProblemSolution()
    solution.permutation = []
    solution.cout = 0

    # choix des villes qui vont initialiser le tour
    # (on prend les plus eloignes)
    premier = 0  # par defaut (0,1)
    dernier = 1
    for i in range(donnees.nbVilles): # pour chaque ville
        for j in range(donnees.nbVilles): # pour chaque ville
            if donnees.matrix[i][j] > donnees.matrix[premier][dernier] : # si la distance (i,j) est plus grande que la distance courante
                premier = i # on met a jour i et j
                dernier = j

    solution.permutation.append(premier) # initialisation de la solution a (premier,dernier)
    solution.permutation.append(dernier)

    # initialisation du tableau de villes non visitees
    villesNonVisitees = [i for i in range(donnees.nbVilles)]
    villesNonVisitees.remove(premier)
    villesNonVisitees.remove(dernier)
    solution.cout = donnees.matrix[premier][dernier] + donnees.matrix[dernier][premier]
    #print("cout initial : " + str(solution.cout))


    # tant que le tour n'est pas complet, on insere l'element qui va le plus reduire la distance totale
    for iteration in range(donnees.nbVilles - 2): # on sait qu'on va ajouter exactement nb villes - 2 villes a la solution
        # initialisation des ajouts par defauts (pour pouvoir comparer)
        best_position = 1
        best_i = solution.permutation[0]
        best_j = solution.permutation[1]
        best_k = villesNonVisitees[0]
        best_gain = donnees.matrix[best_i][best_k] + donnees.matrix[best_k][best_j] - donnees.matrix[best_i][best_j]
        for indicePermutation in range(len(solution.permutation)) : # on parcourt les elements consecutifs dans la solution partielle
            i = solution.permutation[indicePermutation]
            j = solution.permutation[(indicePermutation+1)%len(solution.permutation)]

            for k in villesNonVisitees: # on parcourt les villes restantes
                gain = donnees.matrix[i][k] + donnees.matrix[k][j] - donnees.matrix[i][j]
                if gain < best_gain :
                    best_i = i
                    best_j = j
                    best_k = k
                    best_position = (indicePermutation+1)%len(solution.permutation)
                    best_gain = gain

        #print("Ajout de l'element " + str(best_k) + " en position " + str(best_position))
        solution.permutation.insert(best_position, best_k) # on insere le meilleur dans la solution
        solution.cout += best_gain # et on met a jour le cout de la solution
        villesNonVisitees.remove(best_k) #on enlève la ville k des villes non visitees
    return solution


# calcule un minorant pour la valeur optimale d'une solution
# calcule le minimum par ligne
# calcule la somme des minimums
# soustrait son minimum à chaque ligne
# effectue le meme traitement sur les colonnes de ma matrice restante
# Note : les diagonales (0) ne sont pas considérées dans le min (et ne font pas l'objet de la soustraction)
def calculeMinorant(donnees):
    val = 0

    matriceTSP = copy.deepcopy(donnees.matrix)

    for i in range(donnees.nbVilles): # pour chaque ligne de la matrice
        minLigne = matriceTSP[i][(i+1)%donnees.nbVilles] # calcul du minimum sur la ligne
        for j in range(donnees.nbVilles):
            if i != j and minLigne > matriceTSP[i][j] :
                minLigne = matriceTSP[i][j]
        val += minLigne     # on ajoute la valeur du minimum a la borne
        for j in range(donnees.nbVilles): # et on la soustrait sur la ligne
            if i != j :
                matriceTSP[i][j] -= minLigne

    for i in range(donnees.nbVilles): # pour chaque ligne de la matrice
        minColonne = matriceTSP[(i+1)%donnees.nbVilles][i]
        for j in range(donnees.nbVilles):
            if i != j and minColonne > matriceTSP[j][i] :
                minColonne = matriceTSP[j][i]
        val += minColonne   # on ajoute la valeur du minimum a la borne
        for j in range(donnees.nbVilles):  # et on la soustrait sur la colonne
            if i != j :
                matriceTSP[j][i] -= minColonne

    #print(matriceTSP) # debug : affiche la matrice pretraitee

    return val
