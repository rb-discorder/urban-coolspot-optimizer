#! usr/bin/python
# -*- coding: utf-8 -*-
import sys
import time

import dataTSP
import solutionTSP
import solveTSP
import checkerTSP

def afficheAide():
    print("Erreur : le nombre de parametres doit etre compris entre 2 et 3")
    print("usage : python solve.py nom_du_fichier_tsp nom_de_la_methode, [nom_fichier_solution]")
    print("Noms possibles pour la methode : help, affiche, idiot, plusproche, insertion minorant")
    print("Si le nom de fichier solution n'est pas defini, le nom choisi sera celui de l'instance complete par .sol")


if len(sys.argv) < 3:
    afficheAide()
    sys.exit()

# lecture du problem a partir du fichier de donnees
nomFichier = sys.argv[1]
print("Lecture du fichier de donnees TSP " + nomFichier)
fichier = open(nomFichier,"r")
donneeTSP = dataTSP.lectureDonneesTSPCoordonnees(fichier)
fichier.close()
print("Donnees lues dans " + nomFichier)

nomMethode = sys.argv[2] # on recupere le nom de la methode donne par l'utilisateur

tempsDebut = time.time()

if nomMethode == "affiche":
    # affichage de la donnee (pour le debug)
    dataTSP.afficheInstanceTSP(donneeTSP)
    sys.exit() # on sort du programme directement

elif nomMethode == "idiot": # resolution du probleme avec la methode idiote
    print("Methode utilisee : indice croissant")
    solution = solveTSP.resolutionTSPIdiote(donneeTSP)

elif nomMethode == "plusproche": # resolution du probleme avec la methode du plus proche voisin
    print("Methode utilisee : plus proche voisin")
    solution = solveTSP.resolutionTSPPlusProcheVoisin(donneeTSP, 0)

elif nomMethode == "insertion": # resolution du probleme avec la methode de la meilleure insertion
    print("Methode utilisee : meilleure insertion")
    solution = solveTSP.resolutionTSPMeilleureInsertion(donneeTSP)

elif nomMethode == "minorant": # calcul d'un minorant pour la valeur du TSP (pas de solution calculee)
    minorant = solveTSP.calculeMinorant(donneeTSP)
    print("Minorant = " + str(minorant))
    sys.exit()

else:   # si on a un autre nom de methode, c'est une erreur, ou un appel à help
    afficheAide()
    sys.exit()

#
# si on atteint ce morceau de code, c'est qu'on a calcule une solution
#

# affichage du temps de calcul
tempsEcoule = round(time.time() - tempsDebut, 4)
print("Temps ecoule : " + str(tempsEcoule))

# affichage du cout de la solution
print("La solution a pour cout " + str(solution.cout))

if checkerTSP.verifieSolution(solution,donneeTSP) == False :
    print("Erreur : la solution n'est pas valide")
else :
    print("La solution est valide")

# ecriture de la solution dans le fichier de sortie
if len(sys.argv) == 3:
    print("Pas de non de solution specifie")
    nomFichierSolution = nomFichier + ".sol"
else:
    nomFichierSolution = sys.argv[3]

print("La solution a ete sauvegardee dans le fichier " + nomFichierSolution)
fichierSolution = open(nomFichierSolution,"w")
solutionTSP.recordSolution(solution, fichierSolution)
fichierSolution.close()

# affichage du resume de l'experimentation (pour les stats)
print("Bilan;" + nomFichier + ";" +  sys.argv[2] + ";" + str(solution.cout) + ";" + str(tempsEcoule))
