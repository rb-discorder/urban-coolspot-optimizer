# -*- coding: utf-8 -*-
import sys

import dataTSP
import solutionTSP

# calcule le cout d'une solution
# et modifie le champ cout de la solution avec cette valeur
def calculCout(solution, donnees):
    cout = 0
    for i in range(1,donnees.nbVilles):
        ville_precedente = solution.permutation[i-1]
        ville_courante = solution.permutation[i]
        #print(ville_precedente, ville_courante)
        cout += donnees.matrix[ville_precedente][ville_courante]
    premiere_ville = solution.permutation[0]
    derniere_ville = solution.permutation[donnees.nbVilles-1]
    #print(derniere_ville,premiere_ville)
    cout += donnees.matrix[derniere_ville][premiere_ville]
    return cout


# verifie que la solution est bien valide pour le probleme
# 1) verifie que toutes les villes sont visitees
# 2) verifie que le cout a ete calcule convenablement
def verifieSolution(solution, donnees):
    testTable = [False for i in range(donnees.nbVilles)]
    feas = True
    for i in solution.permutation:
        if testTable[i] == True:
            print("Checker : la ville " + str(i) + " est visitee au moins deux fois")
            feas = False
        testTable[i] = True

    for i in range(donnees.nbVilles):
        if testTable[i] == False:
            print("Checker : la ville " + str(i) + " n'est pas visitee")
            feas = False

    if calculCout(solution, donnees) != solution.cout :
        print("Checker : le cout de la solution n'est pas correct")
        print("Cout dans la solution : " + str(solution.cout))
        print("Cout calcule par le checker : " + str(calculCout(solution, donnees)))
        feas = False

    return feas
